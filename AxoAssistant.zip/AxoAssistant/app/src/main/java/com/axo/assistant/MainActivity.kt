package com.axo.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.axo.assistant.ui.AxoApp
import com.axo.assistant.ui.AxoTheme

class MainActivity : ComponentActivity() {

    private var startAfterGrant = false

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (startAfterGrant) {
            startAfterGrant = false
            if (granted(Manifest.permission.RECORD_AUDIO)) startAxo()
            else Toast.makeText(this, "Mic permission ke bina Axo nahi sun sakta", Toast.LENGTH_LONG).show()
        }
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun startAxo() {
        ContextCompat.startForegroundService(this, Intent(this, AxoService::class.java))
    }

    private fun toggleListening() {
        if (Store.listening) {
            stopService(Intent(this, AxoService::class.java))
            return
        }
        val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = need.filter { !granted(it) }
        if (missing.isEmpty()) startAxo()
        else {
            startAfterGrant = true
            permLauncher.launch(missing.toTypedArray())
        }
    }

    private fun grantAll() {
        val all = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) all.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = all.filter { !granted(it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        setContent {
            AxoTheme {
                AxoApp(onToggle = ::toggleListening, onGrantAll = ::grantAll)
            }
        }
    }
}
