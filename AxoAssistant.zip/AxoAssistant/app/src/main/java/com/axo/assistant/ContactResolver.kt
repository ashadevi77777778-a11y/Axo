package com.axo.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat

object ContactResolver {
    /** Number mein country code na ho (10 digit) to ye laga diya jata hai. India = 91. */
    const val DEFAULT_COUNTRY_CODE = "91"

    private val aliases = mapOf(
        "papa" to listOf("papa", "पापा", "dad", "daddy", "pappa"),
        "mummy" to listOf("mummy", "मम्मी", "mom", "maa", "मां", "mama"),
        "mom" to listOf("mom", "mummy", "मम्मी", "maa")
    )

    /** Naam se phone number (digits only, country code ke saath) dhundta hai. */
    fun find(ctx: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return null
        val key = name.trim().lowercase()
        val tries = aliases[key] ?: listOf(key)
        for (n in tries) {
            ctx.contentResolver.query(
                Phone.CONTENT_URI,
                arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
                "${Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$n%"),
                null
            )?.use { c ->
                if (c.moveToFirst()) return normalize(c.getString(1))
            }
        }
        return null
    }

    fun normalizeRaw(number: String) = normalize(number)

    private fun normalize(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        if (d.startsWith("0")) d = d.drop(1)
        if (d.length == 10) d = DEFAULT_COUNTRY_CODE + d
        return d
    }
}
