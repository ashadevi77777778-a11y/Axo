package com.axo.assistant

import java.util.Locale

/** Hinglish / English voice text ko Command mein badalta hai. */
object CommandProcessor {
    private const val W = "[\\p{L}\\p{M}]+"
    private val WAKE = Regex(
        "\\b(axo|exo|ekso|aksho|axe o|ax o|ak so|acso|accso)\\b|एक्सो|अक्सो",
        RegexOption.IGNORE_CASE
    )

    /** Wake word ke baad ka index (na mile to null). */
    fun wakeEnd(text: String): Int? = WAKE.find(text)?.let { it.range.last + 1 }

    private fun has(t: String, pattern: String) = Regex(pattern).containsMatchIn(t)
    private fun strip(t: String, words: String) =
        t.replace(Regex("\\b($words)\\b"), " ").replace(Regex("\\s+"), " ").trim()

    fun parse(raw: String): Command {
        var t = WAKE.replace(raw.lowercase(Locale.ROOT), " ")
        t = t.replace(Regex("[,.!?।]"), " ").replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty()) return Command.Unknown(raw)

        // Torch
        if (has(t, "torch|flashlight|flash light|flash|tarch|टॉर्च"))
            return Command.Torch(!has(t, "\\boff\\b|band|bund|bandh|बंद"))

        // Volume
        if (has(t, "volume|awaz|awaaz|आवाज")) {
            val mode = when {
                has(t, "full|max") -> "MAX"
                has(t, "badha|up|increase|zyada|tez|high") -> "UP"
                has(t, "kam|ghata|down|decrease|low|dheere") -> "DOWN"
                has(t, "mute|band|silent") -> "MUTE"
                else -> "UP"
            }
            return Command.Volume(mode)
        }

        // Time
        if (has(t, "kitne baje|time kya|what time|samay|abhi time|time batao|टाइम"))
            return Command.Time

        // Alarm
        if (has(t, "alarm")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm)?").find(t)
                ?: return Command.Unknown(raw)
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val ap = m.groupValues[3]
            if (ap == "pm" && h < 12) h += 12
            if (ap == "am" && h == 12) h = 0
            return Command.Alarm(h % 24, min % 60)
        }

        // WhatsApp / message
        val isWa = has(t, "whats\\s?app|व्हाट्सएप|वाट्सएप|व्हाट्सऐप") || has(t, "\\b(message|msg|sms)\\b")
        if (isWa) {
            val a = Regex("($W)\\s+ko\\s+(.+)$").find(t)
            val b = Regex("(?:send|message|msg)\\s+(.+?)\\s+to\\s+($W)").find(t)
            return when {
                a != null -> Command.WhatsApp(a.groupValues[1], cleanMsg(a.groupValues[2]))
                b != null -> Command.WhatsApp(b.groupValues[2], cleanMsg(b.groupValues[1]))
                else -> Command.OpenApp("whatsapp")
            }
        }

        // Call
        if (has(t, "\\b(call|dial)\\b|कॉल")) {
            val name = strip(t, "call|dial|karo|kardo|kar do|ko|lagao|laga do|laga|to|please")
            return if (name.isEmpty()) Command.Unknown(raw) else Command.Call(name)
        }

        // YouTube
        if (has(t, "youtube|यूट्यूब")) {
            val q = strip(t, "youtube|par|pe|se|on|kholo|search|karo|kardo|play|chalao|dikhao|mein|me|ma")
            return Command.YouTube(q)
        }

        // Spotify / music
        val playWords = has(t, "\\b(play|bajao|chalao|gaana|gana|gaane|song|songs|music)\\b|गाना")
        if (has(t, "spotify") || playWords) {
            if (!playWords) return Command.OpenApp("spotify")
            val q = strip(
                t,
                "spotify|se|mein|me|ma|par|pe|on|background|play|kar do|kardo|karo|chalao|bajao|ek|ka|ki|ko|a|the|please|bhi|laga do|lagao"
            ).ifEmpty { "top hits" }
            return Command.Spotify(q)
        }

        // Open app
        if (has(t, "\\b(kholo|khol do|khol|open|launch)\\b")) {
            val name = strip(t, "kholo|khol do|khol|open|launch|app|ko|karo|kardo|please|chalu|on")
            if (name.isNotEmpty()) return Command.OpenApp(name)
        }

        // Search
        if (has(t, "\\b(search|google|dhundo|khojo)\\b")) {
            val q = strip(t, "search|google|dhundo|khojo|karo|kardo|par|pe|se|mein|me|ma|batao|for|about")
            if (q.isNotEmpty()) return Command.Search(q)
        }
        return Command.Unknown(raw)
    }

    private fun cleanMsg(m: String) = m
        .replace(Regex("\\s+(message|msg)\\s*(karo|bhejo|kardo|kar do|bhej do)?$"), "")
        .replace(Regex("\\s+(bhejo|bhej do|bol do|bolo|likh do)$"), "")
        .trim()
}
