package com.axo.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** WhatsApp mein message pehle se likha hota hai, ye sirf Send button dabata hai. */
class WhatsAppAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!AutomationState.pendingSend) return
        if (System.currentTimeMillis() - AutomationState.pendingAt > 20_000) {
            AutomationState.pendingSend = false
            return
        }
        val root = rootInActiveWindow ?: return
        val node = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
            ?: root.findAccessibilityNodeInfosByViewId("com.whatsapp.w4b:id/send").firstOrNull()
            ?: findByDescription(root)
        if (node != null && clickUp(node)) {
            AutomationState.pendingSend = false
            Speaker.speak("Message bhej diya")
        }
    }

    private fun findByDescription(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        val d = n.contentDescription?.toString()?.trim()
        if (d != null && (d.equals("Send", true) || d == "भेजें")) return n
        for (i in 0 until n.childCount) {
            findByDescription(n.getChild(i))?.let { return it }
        }
        return null
    }

    private fun clickUp(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            n = n.parent
        }
        return false
    }

    override fun onInterrupt() {}
}
