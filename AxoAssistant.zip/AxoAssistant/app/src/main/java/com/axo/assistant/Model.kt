package com.axo.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

enum class Kind { CHAT, MUSIC, VIDEO, CALL, SEARCH, TIME, APP, TORCH, VOLUME, ALARM, UNKNOWN }

sealed class Command(val kind: Kind) {
    data class WhatsApp(val name: String, val message: String) : Command(Kind.CHAT)
    data class Spotify(val query: String) : Command(Kind.MUSIC)
    data class YouTube(val query: String) : Command(Kind.VIDEO)
    data class Call(val name: String) : Command(Kind.CALL)
    data class Search(val query: String) : Command(Kind.SEARCH)
    data class OpenApp(val name: String) : Command(Kind.APP)
    data class Torch(val on: Boolean) : Command(Kind.TORCH)
    data class Volume(val mode: String) : Command(Kind.VOLUME)
    data class Alarm(val hour: Int, val minute: Int) : Command(Kind.ALARM)
    object Time : Command(Kind.TIME)
    data class Unknown(val text: String) : Command(Kind.UNKNOWN)
}

data class HistoryItem(val command: String, val reply: String, val kind: Kind)

/** UI ke liye shared state. */
object Store {
    var listening by mutableStateOf(false)
    var status by mutableStateOf("Axo soya hua hai. Mic dabao aur bolo: Axo...")
    val history = mutableStateListOf<HistoryItem>()

    fun add(item: HistoryItem) {
        history.add(0, item)
        while (history.size > 50) history.removeAt(history.lastIndex)
    }
}

/** WhatsApp message auto-send ke liye flag. */
object AutomationState {
    @Volatile var pendingSend = false
    @Volatile var pendingAt = 0L
}

object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                tts?.language = Locale("en", "IN")
            }
        }
    }

    fun speak(text: String) {
        if (ready) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "axo")
    }
}

object Assistant {
    /** Text command ko samajh kar chalata hai, history mein dalta hai aur bol kar jawab deta hai. */
    fun execute(ctx: Context, raw: String) {
        val app = ctx.applicationContext
        val cmd = CommandProcessor.parse(raw)
        val reply = Actions.run(app, cmd)
        Store.add(HistoryItem(raw.trim(), reply, cmd.kind))
        Store.status = reply
        Speaker.speak(reply)
    }
}
