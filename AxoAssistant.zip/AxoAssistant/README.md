# Axo Assistant (Android, Kotlin + Jetpack Compose)

## Kaise chalayen
1. Android Studio (Koala ya naya) install karo.
2. File > Open > is `AxoAssistant` folder ko chuno. Gradle sync apne aap hoga (internet chahiye).
3. Phone mein Developer options > USB debugging on karo, phone connect karo, Run dabao.
   APK chahiye to: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. App kholo > neeche **Profile** tab > sab "Allow" karo:
   Microphone, Contacts, Phone, Display over other apps, Accessibility (Axo), Battery unrestricted.
5. Home par mic dabao. Ab bolo: "Axo, Spotify se english song play kardo".

## Zaroori baatein
- Spotify aur WhatsApp phone mein installed aur login hone chahiye.
- Android 13+ par Accessibility grey ho to: App info > teen dot > Allow restricted settings.
- Phone restart ke baad app ek baar kholkar mic dabana padega (Android 14 ki rok).
- 10 digit numbers par country code `91` lagta hai. Badalna ho to `ContactResolver.kt` mein `DEFAULT_COUNTRY_CODE`.
- Wake word Google ki speech recognition se chalta hai, isliye internet chahiye aur kuch phones par
  har sunne par halki beep aa sakti hai.

## Files
- `AxoService.kt` background wake word "Axo"
- `CommandProcessor.kt` Hinglish command samajhna
- `Actions.kt` Spotify, WhatsApp, call, torch, volume, alarm, app kholna
- `WhatsAppAccessibilityService.kt` WhatsApp mein Send dabana
- `ui/Screens.kt`, `ui/Theme.kt` Crimson + Neon Purple UI
